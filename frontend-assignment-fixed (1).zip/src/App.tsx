import React, { useState } from 'react'
import { InputField } from './components/InputField/InputField'
import { DataTable, Column } from './components/DataTable/DataTable'

type User = { id: number; name: string; email: string; age: number }

const sampleData: User[] = [
  { id: 1, name: 'Alice', email: 'alice@example.com', age: 29 },
  { id: 2, name: 'Bob', email: 'bob@example.com', age: 22 },
  { id: 3, name: 'Charlie', email: 'charlie@example.com', age: 34 },
]

const columns: Column<User>[] = [
  { key: 'name', title: 'Name', dataIndex: 'name', sortable: true },
  { key: 'email', title: 'Email', dataIndex: 'email', sortable: true },
  { key: 'age', title: 'Age', dataIndex: 'age', sortable: true },
]

export default function App() {
  const [value, setValue] = useState('')
  return (
    <div className="p-6 max-w-4xl mx-auto space-y-8">
      <section className="space-y-3">
        <h1 className="text-2xl font-bold">Frontend Assignment Demo</h1>
        <InputField
          label="Your name"
          placeholder="Type your name"
          value={value}
          onChange={(e) => setValue(e.target.value)}
          helperText="Helper text shows here"
          variant="outlined"
          size="md"
        />
      </section>

      <section className="space-y-3">
        <h2 className="text-xl font-semibold">Users</h2>
        <DataTable<User>
          data={sampleData}
          columns={columns}
          loading={false}
          selectable={true}
          onRowSelect={(rows) => console.log('Selected', rows)}
        />
      </section>
    </div>
  )
}
