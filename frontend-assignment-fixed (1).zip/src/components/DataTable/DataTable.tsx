import React, { useMemo, useState } from 'react'

export interface Column<T> {
  key: string
  title: string
  dataIndex: keyof T
  sortable?: boolean
  render?: (value: any, record: T) => React.ReactNode
}

export interface DataTableProps<T> {
  data: T[]
  columns: Column<T>[]
  loading?: boolean
  selectable?: boolean
  onRowSelect?: (selectedRows: T[]) => void
}

type SortConfig = { key: string; direction: 'asc' | 'desc' } | null

function compareValues(a: any, b: any) {
  if (a == null && b == null) return 0
  if (a == null) return -1
  if (b == null) return 1
  const aNum = typeof a === 'number' || a instanceof Date
  const bNum = typeof b === 'number' || b instanceof Date
  if (aNum && bNum) {
    return Number(a) < Number(b) ? -1 : Number(a) > Number(b) ? 1 : 0
  }
  return String(a).localeCompare(String(b))
}

export function DataTable<T extends Record<string, any>>({
  data,
  columns,
  loading = false,
  selectable = false,
  onRowSelect,
}: DataTableProps<T>) {
  const [sortConfig, setSortConfig] = useState<SortConfig>(null)
  const [selectedIndexes, setSelectedIndexes] = useState<Set<number>>(new Set())

  const sorted = useMemo(() => {
    if (!sortConfig) return data
    const col = columns.find((c) => c.key === sortConfig.key)
    if (!col) return data
    return [...data].sort((ra, rb) => {
      const res = compareValues(ra[col.dataIndex], rb[col.dataIndex])
      return sortConfig.direction === 'asc' ? res : -res
    })
  }, [data, columns, sortConfig])

  const toggleSort = (key: string) => {
    setSortConfig((prev) => {
      if (!prev || prev.key !== key) return { key, direction: 'asc' }
      return { key, direction: prev.direction === 'asc' ? 'desc' : 'asc' }
    })
  }

  const toggleRow = (index: number) => {
    if (!selectable) return
    const next = new Set(selectedIndexes)
    if (next.has(index)) next.delete(index)
    else next.add(index)
    setSelectedIndexes(next)
    onRowSelect?.(Array.from(next).map((i) => sorted[i]))
  }

  if (loading) {
    return (
      <div className="p-4 animate-pulse text-sm text-gray-500">Loading…</div>
    )
  }

  if (!sorted.length) {
    return <div className="p-4 text-sm text-gray-500">No data available.</div>
  }

  return (
    <div className="overflow-x-auto rounded-lg border border-gray-200 dark:border-gray-700">
      <table className="min-w-full text-left">
        <thead className="bg-gray-100 dark:bg-gray-800/60 text-gray-700 dark:text-gray-200 text-sm">
          <tr>
            {selectable && <th className="w-10 px-4 py-2"></th>}
            {columns.map((col) => {
              const isSorted = sortConfig?.key === col.key
              const ariaSort = isSorted ? (sortConfig!.direction === 'asc' ? 'ascending' : 'descending') : 'none'
              return (
                <th
                  key={col.key}
                  scope="col"
                  className={['px-4 py-2 font-semibold', col.sortable ? 'cursor-pointer select-none' : ''].join(' ')}
                  onClick={() => col.sortable && toggleSort(col.key)}
                  aria-sort={ariaSort as any}
                >
                  <span className="inline-flex items-center gap-1">
                    {col.title}
                    {col.sortable && (
                      <span aria-hidden="true">
                        {isSorted ? (sortConfig!.direction === 'asc' ? '▲' : '▼') : '⇅'}
                      </span>
                    )}
                  </span>
                </th>
              )
            })}
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-200 dark:divide-gray-800">
          {sorted.map((row, idx) => {
            const selected = selectedIndexes.has(idx)
            return (
              <tr key={idx} className={selected ? 'bg-blue-50 dark:bg-blue-900/20' : ''}>
                {selectable && (
                  <td className="px-4 py-2">
                    <input
                      type="checkbox"
                      aria-label={`Select row ${idx + 1}`}
                      checked={selected}
                      onChange={() => toggleRow(idx)}
                    />
                  </td>
                )}
                {columns.map((col) => (
                  <td key={col.key} className="px-4 py-2 text-sm">
                    {col.render ? col.render(row[col.dataIndex], row) : String(row[col.dataIndex] ?? '')}
                  </td>
                ))}
              </tr>
            )
          })}
        </tbody>
      </table>
    </div>
  )
}
