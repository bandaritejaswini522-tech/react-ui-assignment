import type { Meta, StoryObj } from '@storybook/react'
import React, { useState } from 'react'
import { InputField, type InputFieldProps } from './InputField'

const meta: Meta<typeof InputField> = {
  title: 'Components/InputField',
  component: InputField,
  argTypes: {
    variant: { control: 'radio', options: ['filled', 'outlined', 'ghost'] },
    size: { control: 'radio', options: ['sm', 'md', 'lg'] },
    type: { control: 'radio', options: ['text', 'password'] },
  },
}
export default meta
type Story = StoryObj<typeof InputField>

export const Playground: Story = {
  args: {
    label: 'Label',
    placeholder: 'Type here',
    helperText: 'Helper text',
    variant: 'outlined',
    size: 'md',
    type: 'text',
  },
}

export const Controlled: Story = {
  render: (args: InputFieldProps) => {
    const [val, setVal] = useState('')
    return (
      <div className="max-w-md">
        <InputField {...args} value={val} onChange={(e) => setVal(e.target.value)} />
        <div className="mt-2 text-sm opacity-70">Value: {val}</div>
      </div>
    )
  },
  args: {
    label: 'Controlled',
    placeholder: 'Type...',
  },
}

export const Password: Story = {
  args: {
    label: 'Password',
    placeholder: 'Enter password',
    type: 'password',
  },
}

export const Invalid: Story = {
  args: {
    label: 'Email',
    placeholder: 'you@example.com',
    invalid: true,
    errorMessage: 'Please enter a valid email address',
  },
}

export const Loading: Story = {
  args: {
    label: 'Searching',
    placeholder: 'Type to search...',
    loading: true,
  },
}

export const Disabled: Story = {
  args: {
    label: 'Disabled',
    placeholder: 'Not editable',
    disabled: true,
  },
}
