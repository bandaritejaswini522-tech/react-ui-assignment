import React, { useId, useMemo, useState } from 'react'

export interface InputFieldProps {
  value?: string
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void
  label?: string
  placeholder?: string
  helperText?: string
  errorMessage?: string
  disabled?: boolean
  invalid?: boolean
  variant?: 'filled' | 'outlined' | 'ghost'
  size?: 'sm' | 'md' | 'lg'
  type?: 'text' | 'password'
  loading?: boolean
}

const sizeClasses: Record<NonNullable<InputFieldProps['size']>, string> = {
  sm: 'h-9 px-3 text-sm',
  md: 'h-10 px-3.5 text-base',
  lg: 'h-12 px-4 text-lg',
}

const variantClasses: Record<NonNullable<InputFieldProps['variant']>, string> = {
  filled:
    'bg-gray-100 dark:bg-gray-800 border border-transparent focus:border-blue-500 focus:ring-2 focus:ring-blue-200 dark:focus:ring-blue-900',
  outlined:
    'bg-white dark:bg-gray-900 border border-gray-300 dark:border-gray-700 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 dark:focus:ring-blue-900',
  ghost:
    'bg-transparent border-b border-gray-300 dark:border-gray-700 focus:border-blue-500 focus:ring-0 rounded-none',
}

function Spinner() {
  return (
    <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24" aria-hidden="true">
      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z" />
    </svg>
  )
}

export const InputField: React.FC<InputFieldProps> = (props) => {
  const {
    value,
    onChange,
    label,
    placeholder,
    helperText,
    errorMessage,
    disabled,
    invalid,
    variant = 'outlined',
    size = 'md',
    type = 'text',
    loading = false,
  } = props

  const internalId = useId()
  const inputId = useMemo(() => `input-${internalId}`, [internalId])
  const helperId = `${inputId}-helper`
  const errorId = `${inputId}-error`

  const [internal, setInternal] = useState<string>(value ?? '')
  const currentValue = value !== undefined ? value : internal

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onChange?.(e)
    if (value === undefined) setInternal(e.target.value)
  }

  const [showPassword, setShowPassword] = useState<boolean>(false)
  const actualType = type === 'password' ? (showPassword ? 'text' : 'password') : 'text'

  const showClear = !disabled && !loading && !!currentValue && type !== 'password'

  const base =
    'w-full rounded-md outline-none transition ring-offset-1 disabled:cursor-not-allowed disabled:opacity-50 dark:placeholder:text-gray-400 placeholder:text-gray-500'

  return (
    <div className="flex flex-col w-full">
      {label && (
        <label htmlFor={inputId} className="mb-1 text-sm font-medium text-gray-700 dark:text-gray-300">
          {label}
        </label>
      )}
      <div className="relative">
        <input
          id={inputId}
          type={actualType}
          value={currentValue}
          onChange={handleChange}
          placeholder={placeholder}
          disabled={disabled}
          aria-invalid={invalid || undefined}
          aria-busy={loading || undefined}
          aria-describedby={invalid && errorMessage ? errorId : helperText ? helperId : undefined}
          className={[
            base,
            sizeClasses[size],
            variantClasses[variant],
            invalid ? 'border-red-500 focus:border-red-500 focus:ring-red-200 dark:focus:ring-red-900' : '',
            type === 'password' ? 'pr-20' : 'pr-10',
          ]
            .filter(Boolean)
            .join(' ')}
        />

        <div className="absolute inset-y-0 right-2 flex items-center gap-2">
          {loading && <Spinner />}

          {type === 'password' && (
            <button
              type="button"
              onClick={() => setShowPassword((s) => !s)}
              className="text-sm px-2 py-1 rounded-md hover:bg-gray-100 dark:hover:bg-gray-800"
              aria-label={showPassword ? 'Hide password' : 'Show password'}
              tabIndex={-1}
            >
              {showPassword ? 'Hide' : 'Show'}
            </button>
          )}

          {showClear && (
            <button
              type="button"
              onClick={() => handleChange({ target: { value: '' } } as any)}
              className="text-xl leading-none px-2 py-1 rounded-md hover:bg-gray-100 dark:hover:bg-gray-800"
              aria-label="Clear input"
              tabIndex={-1}
            >
              ×
            </button>
          )}
        </div>
      </div>

      {invalid && errorMessage ? (
        <p id={errorId} className="mt-1 text-xs text-red-600">
          {errorMessage}
        </p>
      ) : helperText ? (
        <p id={helperId} className="mt-1 text-xs text-gray-500 dark:text-gray-400">
          {helperText}
        </p>
      ) : null}
    </div>
  )
}
